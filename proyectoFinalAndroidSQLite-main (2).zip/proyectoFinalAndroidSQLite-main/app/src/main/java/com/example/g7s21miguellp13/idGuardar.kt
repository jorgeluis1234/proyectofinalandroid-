package com.example.g7s21miguellp13

class idGuardar {
    private var ide: Int = 0

    fun change(id: Int) {
        ide=id
    }
    fun ret(): Int{
        return(ide)
    }


}